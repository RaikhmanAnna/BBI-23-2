interface IStatistic{
    double MaxQuality();
    double MinQuality();
    double AverrageQuality();
    double MedianQuality();
}